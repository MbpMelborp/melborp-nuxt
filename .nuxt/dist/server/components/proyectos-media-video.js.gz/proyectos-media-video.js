exports.ids = [19];
exports.modules = {

/***/ 114:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 115:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_video[data-v-03da436c]{display:grid;grid-template-columns:repeat(5, minmax(0, 1fr));}.media_video .media_video_wrapper[data-v-03da436c]{padding-top:56%}.media_video .media_video_wrapper[data-v-03da436c]{position:relative;}.media_video .media_video_wrapper[data-v-03da436c]{height:0px;}.media_video .media_video_wrapper[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper[data-v-03da436c]{align-self:center;}.media_video .media_video_wrapper.center[data-v-03da436c]{grid-column:1 / -1;}.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column-start:1;}}@media (min-width: 768px){.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column-end:5;}}.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{order:2;}}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column-start:2;}}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column-end:6;}}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{position:absolute;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{top:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{right:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{left:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{bottom:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{display:inline-block;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{height:100%;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{-o-object-fit:contain;object-fit:contain;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{background-position:50% 50%;background-size:100% 100%;transition:opacity .8s,height 0s;transition-delay:0s,0s}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{position:absolute;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{top:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{right:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{left:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{bottom:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{height:100%;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{cursor:pointer;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{overflow:hidden;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{border-style:none;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{background-size:cover;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{font-size:0.875rem;line-height:1.25rem;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{opacity:1;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{outline:2px solid transparent;outline-offset:2px;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-variation-settings:\"wght\" 100,\"wdth\" 80,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,100),\"wdth\" var(--font-width,80),\"ital\" 0}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-size:6rem;line-height:1;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{letter-spacing:-0.05em;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{--tw-text-opacity:1;color:rgba(255, 255, 255, var(--tw-text-opacity));}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{--tw-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.05);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms;}@media (min-width: 768px){.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-size:8rem;line-height:1;}}.media_video .media_video_wrapper .media_video_poster b i[data-v-03da436c]{font-size:1.5rem;line-height:2rem;}@media (min-width: 768px){.media_video .media_video_wrapper .media_video_poster b i[data-v-03da436c]{font-size:3.75rem;line-height:1;}}.media_video .media_video_wrapper .media_video_poster.dif b span[data-v-03da436c]{position:relative;-webkit-mix-blend-mode:overlay;-moz-mix-blend-mode:overlay;-o-mix-blend-mode:overlay;-ms-mix-blend-mode:overlay;mix-blend-mode:overlay}.media_video .media_video_wrapper .media_video_poster:hover b[data-v-03da436c]{font-variation-settings:\"wght\" 400,\"wdth\" 120,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,400),\"wdth\" var(--font-width,120),\"ital\" 0}.media_video .media_video_content[data-v-03da436c]{margin-top:2rem;margin-bottom:2rem;}.media_video .media_video_content[data-v-03da436c]{align-self:center;}.media_video .media_video_content.center[data-v-03da436c]{grid-column-start:3;}.media_video .media_video_content.center[data-v-03da436c]{grid-column-end:6;}.media_video .media_video_content.left[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{grid-column-start:5;}}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{grid-column-end:6;}}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{padding:2rem;}}.media_video .media_video_content.right[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{order:1;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{grid-column-start:1;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{grid-column-end:2;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{padding:2rem;}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 133:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_video.vue?vue&type=template&id=03da436c&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"media_video"},[_vm._ssrNode("<div"+(_vm._ssrClass(null,("media_video_wrapper " + (_vm.media.posicion))))+" data-v-03da436c>","</div>",[_c('video',{directives:[{name:"intersection",rawName:"v-intersection",value:(_vm.handlerStopVideo),expression:"handlerStopVideo"}],ref:("video_" + (_vm.media._uid)),staticClass:"media_video_player",attrs:{"loading":"lazy","controls":"","src":_vm.media.video.filename,"preload":"auto","poster":_vm.media.poster.filename + '/m/'}},[]),_vm._ssrNode(" "),_c('button',{directives:[{name:"cursor-right",rawName:"v-cursor-right"},{name:"lazy-background",rawName:"v-lazy-background"}],staticClass:"media_video_poster dif",attrs:{"id":("video_btn_" + (_vm.media._uid)),"lazy-background":_vm.media.poster.filename + '/m/'},on:{"click":_vm.playVideo}},[_vm._ssrNode("<b class=\"t proy_link btn-mbp hvr-sweep-to-top\" data-v-03da436c><span data-v-03da436c> Play <i class=\"fal fa-play\" data-v-03da436c></i></span></b>")])],2),_vm._ssrNode(" "),(_vm.showdesc)?[_vm._ssrNode(((_vm.media.descripcion)?("<div"+(_vm._ssrClass(null,("descripcion media_video_content " + (_vm.media.posicion))))+" data-v-03da436c>"+(_vm._s(_vm.$storyapi.richTextResolver.render(_vm.media.descripcion)))+"</div>"):"<!---->"))]:_vm._e()],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_video.vue?vue&type=template&id=03da436c&scoped=true&

// EXTERNAL MODULE: ./node_modules/gsap/dist/gsap.js
var gsap = __webpack_require__(7);

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_video.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Media_videovue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {
      showdesc: true
    };
  },

  mounted() {
    console.log('VIEDO', this.$storyapi.richTextResolver.render(this.media.descripcion));

    if (this.$storyapi.richTextResolver.render(this.media.descripcion) === '<p></p>') {
      this.showdesc = false;
    }
  },

  methods: {
    playVideo(e) {
      this.$refs[`video_${this.media._uid}`].play();
      gsap["gsap"].to(`#video_btn_${this.media._uid}`, {
        //   clipPath: 'inset(0% 0% 0% 0%)',
        autoAlpha: 0,
        duration: 1,
        onComplete: () => {},
        ease: gsap["Expo"].easeInOut
      });
    },

    stopVideo() {
      const videop = this.$refs[`video_${this.media._uid}`];
      videop.pause();
      videop.currentTime = 0;
      gsap["gsap"].to(`#video_btn_${this.media._uid}`, {
        //   clipPath: 'inset(0% 0% 0% 0%)',
        autoAlpha: 1,
        duration: 0.5,
        onComplete: () => {},
        ease: gsap["Expo"].easeInOut
      });
    },

    handlerStopVideo(e, observer, isIntersecting, ratio) {
      if (!isIntersecting) this.stopVideo();
    }

  }
});
// CONCATENATED MODULE: ./components/proyectos/Media_video.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_videovue_type_script_lang_js_ = (Media_videovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_video.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(114)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_videovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "03da436c",
  "7913212a"
  
)

/* harmony default export */ var Media_video = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 89:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["a"] = ({
  mounted() {
    if (window) {
      window.dispatchEvent(new Event('resize'));
    }

    this.$Lazyload.$on('loading', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        window.dispatchEvent(new Event('resize'));
      }

      if (el.classList.contains('vlazy')) {
        if (this.$isMobile()) {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(el, {
            clipPath: 'inset(0% 0% 100% 0%)',
            scaleY: 1.1,
            autoAlpha: 0
          });
        } else {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(el, {
            clipPath: 'inset(0% 0% 0% 0%)',
            scaleY: 1,
            autoAlpha: 0
          });
        }
      }
    });
    this.$Lazyload.$on('loaded', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        if (el.classList.contains('vlazy')) {
          if (el.classList.contains('vlazy')) {
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(el, {
              clipPath: 'inset(0% 0% 0% 0%)',
              scaleY: 1,
              autoAlpha: 1,
              duration: 0.5,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {
                window.dispatchEvent(new Event('resize'));
              }
            });
          } else {
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(el, {
              clipPath: 'inset(0% 0% 0% 0%)',
              scaleY: 1,
              autoAlpha: 1,
              duration: 0.8,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {
                window.dispatchEvent(new Event('resize'));
              }
            });
          }
        }
      }
    });
  },

  methods: {
    loaded(e) {
      if (window) {
        if (!e.target.classList.contains('isLoaded') && !e.target.classList.contains('isLoading')) {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(e.target, {
            // clipPath: 'inset(0% 0% 100% 0%)',
            // webkitClipPath: 'inset(0% 0% 100% 0%)',
            scaleY: 1,
            autoAlpha: 0
          });
        } else {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(e.target, {
            // clipPath: 'inset(0% 0% 0% 0%)',
            // webkitClipPath: 'inset(0% 0% 0% 0%)',
            scaleY: 1,
            autoAlpha: 1,
            duration: 0.5,
            ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
            onStart: () => {
              window.dispatchEvent(new Event('resize'));
            }
          });
        }
      }
    },

    clipToRight(e, observer, isIntersecting, ratio) {
      if (isIntersecting) {
        console.log('👓', ' clipToRight', isIntersecting, e, observer);
        e.forEach(function (entry, i) {
          if (entry.target.loaded === false || entry.target.loaded === undefined) {
            entry.target.loaded = true;
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].fromTo(entry.target, {
              clipPath: 'inset(0% 100% 0% 0%)',
              y: 10
            }, {
              clipPath: 'inset(0% 0% 0% 0%)',
              y: 0,
              duration: 1,
              delay: 0.2,
              stagger: i * 0.2,
              overwrite: false,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {},
              onComplete: () => {
                gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].killTweensOf(entry.target);
              }
            });
          }
        });
      }
    },

    clipToTop(e, observer, isIntersecting, ratio) {
      if (isIntersecting) {
        console.log('👓', ' clipToRight', isIntersecting, e, observer);
        e.forEach(function (entry, i) {
          if (entry.target.loaded === false || entry.target.loaded === undefined) {
            entry.target.loaded = true;
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].fromTo(entry.target, {
              clipPath: 'inset(100% 0% 0% 0%)',
              y: 10
            }, {
              clipPath: 'inset(0% 0% 0% 0%)',
              y: 0,
              duration: 1,
              delay: 0.2,
              stagger: i * 0.2,
              overwrite: false,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {},
              onComplete: () => {
                gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].killTweensOf(entry.target);
              }
            });
          }
        });
      }
    }

  }
});

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(115);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("594f6c7c", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=proyectos-media-video.js.map