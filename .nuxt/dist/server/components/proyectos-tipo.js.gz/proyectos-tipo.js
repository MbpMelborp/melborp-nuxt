exports.ids = [21];
exports.modules = {

/***/ 106:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Tipo_vue_vue_type_style_index_0_id_4a7b4c04_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Tipo_vue_vue_type_style_index_0_id_4a7b4c04_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Tipo_vue_vue_type_style_index_0_id_4a7b4c04_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Tipo_vue_vue_type_style_index_0_id_4a7b4c04_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Tipo_vue_vue_type_style_index_0_id_4a7b4c04_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 107:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".proyecto_tipo[data-v-4a7b4c04]{margin-left:auto;margin-right:auto;width:100%;max-width:1920px}.proyecto_data[data-v-4a7b4c04]{z-index:30}@media (min-width: 768px){.proyecto_data[data-v-4a7b4c04]{padding-top:5rem}}.proyecto_data .proyecto_data_int[data-v-4a7b4c04]{opacity:0}@media (min-width: 768px){.proyecto_data .proyecto_data_int .proyecto_data_content[data-v-4a7b4c04]{margin-top:0.5rem}}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{font-variation-settings:\"wght\" 850,\"wdth\" 140,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,850),\"wdth\" var(--font-width,140),\"ital\" 0}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{margin-bottom:1rem}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{font-size:1.25rem;line-height:1.75rem}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{text-transform:uppercase}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{line-height:1}@media (max-width:768px){.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{font-variation-settings:\"wght\" 600,\"wdth\" 120,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,600),\"wdth\" var(--font-width,120),\"ital\" 0}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{font-size:1.5rem;line-height:2rem}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{text-transform:none}.proyecto_data .proyecto_data_int .proyecto_data_content h4[data-v-4a7b4c04]{line-height:1.25}}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{margin-bottom:1rem}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{font-size:0.875rem;line-height:1.25rem}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{font-weight:100}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{line-height:1.25rem}@media (min-width: 1024px){.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{margin-left:2rem}}@media (min-width: 1024px){.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{margin-right:0.75rem}}@media (max-width:768px){.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body[data-v-4a7b4c04]{font-size:1.125rem;line-height:1.75rem}}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_body p[data-v-4a7b4c04]{margin-bottom:0.5rem}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{font-size:1rem;line-height:1.5rem}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{font-weight:300}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{text-transform:uppercase}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{letter-spacing:0.1em}@media (min-width: 1024px){.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{margin-left:0.5rem}}@media (max-width:768px){.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver[data-v-4a7b4c04]{margin-left:0px}}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver svg[data-v-4a7b4c04]{width:45px;height:45px}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver svg[data-v-4a7b4c04]{margin-top:0.5rem}.proyecto_data .proyecto_data_int .proyecto_data_content .proyecto_ver svg[data-v-4a7b4c04]{margin-left:1rem}.proyecto_media[data-v-4a7b4c04]{z-index:0;opacity:0}.proyecto_title[data-v-4a7b4c04]{z-index:10;}.proyecto_title .proyecto_title_int .proyecto_title_int_cliente[data-v-4a7b4c04]{font-size:calc(3vw + 3vh + .5vmin);font-variation-settings:\"wght\" 200,\"wdth\" 120,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,200),\"wdth\" var(--font-width,120),\"ital\" 0}.proyecto_title .proyecto_title_int .proyecto_title_int_cliente[data-v-4a7b4c04]{line-height:1}.proyecto_title .proyecto_title_int .proyecto_title_int_nom[data-v-4a7b4c04]{line-height:.8em}.proyecto_title .proyecto_title_int .proyecto_title_int_nom.text-small[data-v-4a7b4c04]{font-size:calc(3vw + 3vh + .5vmin)}.proyecto_title .proyecto_title_int .proyecto_title_int_nom.text-normal[data-v-4a7b4c04]{font-size:calc(4vw + 4vh + .5vmin)}@media (max-width:768px){.proyecto_title .proyecto_title_int .proyecto_title_int_nom[data-v-4a7b4c04]{font-size:2em}}.proyecto_title .proyecto_title_int .proyecto_title_int_nom span[data-v-4a7b4c04]{font-variation-settings:\"wght\" 400,\"wdth\" 130,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,400),\"wdth\" var(--font-width,130),\"ital\" 0;transition:font-variation-settings .5 ease-in-out}@media (max-width:768px){.proyecto_title .proyecto_title_int .proyecto_title_int_nom span[data-v-4a7b4c04]{--font-weight:650}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 108:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Tipo.vue?vue&type=template&id=4a7b4c04&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{directives:[{name:"intersection",rawName:"v-intersection",value:(_vm.handlerShowProy),expression:"handlerShowProy"},{name:"cursor-right",rawName:"v-cursor-right"}],key:Math.random() * 1000 + _vm.proyecto.slug,class:("proyecto_tipo " + (_vm.par ? 'tipo_2' : 'tipo_1')),attrs:{"id":("proyecto_" + (_vm.proyecto.slug)),"data-scroll":"","data-scroll-speed":!_vm.$isMobile() ? 0.1 : 0,"data-scroll-repeat":"true","data-scroll-position":"top","data-scroll-call":("proyecto_" + (_vm.proyecto.slug))},on:{"click":_vm.toProject}},[_c('h2',{directives:[{name:"intersection",rawName:"v-intersection",value:(_vm.handlerHoverMobileProyecto),expression:"handlerHoverMobileProyecto"}],staticClass:"proyecto_title"},[_vm._ssrNode("<div class=\"proyecto_title_int\" data-v-4a7b4c04><div class=\"proyecto_title_int_cliente\" data-v-4a7b4c04>"+_vm._ssrEscape("\n        "+_vm._s(_vm.proyecto.content.cliente)+",\n      ")+"</div> <div"+(_vm._ssrClass("proyecto_title_int_nom",_vm.proyecto.content.nombre.length > 20 ? 'text-small' : 'text-normal'))+" data-v-4a7b4c04>"+(_vm._ssrList((_vm.proyecto.content.nombre.split(' ')),function(palabra,index){return ("<span data-v-4a7b4c04>"+_vm._ssrEscape("\n          "+_vm._s(palabra)+"\n        ")+"</span>")}))+"</div></div>")]),_vm._ssrNode(" <div class=\"proyecto_arrow\" data-v-4a7b4c04><svg viewBox=\"0 0 45 45\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" data-v-4a7b4c04><g stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\" data-v-4a7b4c04><g transform=\"translate(-12.000000, -9.000000)\""+(_vm._ssrAttr("stroke",_vm.proyecto.content.colores[0].texto.color))+" stroke-width=\"1\" data-v-4a7b4c04><g id=\"arrowp\" transform=\"translate(34.374000, 31.374000) scale(-1, 1) translate(-34.374000, -31.374000) translate(13.000000, 10.000000)\" data-v-4a7b4c04><line x1=\"42.748\" y1=\"42.748\" x2=\"0\" y2=\"0\" data-v-4a7b4c04></line> <polyline points=\"42.3738 0.3742 0.3738 0.3742 0.3738 42.3742\" data-v-4a7b4c04></polyline></g></g></g></svg></div> "),_vm._ssrNode("<div class=\"proyecto_data\" data-v-4a7b4c04>","</div>",[_vm._ssrNode("<div class=\"proyecto_data_int\" data-v-4a7b4c04>","</div>",[_vm._ssrNode("<div class=\"proyecto_data_content\" data-v-4a7b4c04>","</div>",[_c('nuxt-link',{directives:[{name:"cursor-right",rawName:"v-cursor-right"}],attrs:{"to":_vm.proyecto.full_slug}},[_c('h4',{staticClass:"anim_proy",on:{"mouseover":function($event){return _vm.hoverProyecto($event, true)},"mouseleave":function($event){return _vm.hoverProyecto($event, false)}}},[_vm._v("\n            "+_vm._s(_vm.proyecto.content.titular)+"\n          ")]),_vm._v(" "),_c('div',{staticClass:"proyecto_body anim_proy",domProps:{"innerHTML":_vm._s(_vm.intro)},on:{"mouseover":function($event){return _vm.hoverProyecto($event, true)},"mouseleave":function($event){return _vm.hoverProyecto($event, false)}}}),_vm._v(" "),_c('div',{staticClass:"proyecto_ver anim_proy",on:{"mouseover":function($event){return _vm.hoverProyecto($event, true)},"mouseleave":function($event){return _vm.hoverProyecto($event, false)}}},[_vm._v("\n            Ver proyecto "),_c('i',{staticClass:"fal fa-long-arrow-right"})])])],1)])]),_vm._ssrNode(" "),_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"proyecto_media proyecto_media_1",attrs:{"id":("proyecto_" + (_vm.proyecto.slug) + "_media_1"),"data-played":"0"}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",_vm.proyecto.content.home[0].media1.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.proyecto.content.home[0].media1.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.proyecto.content.home[0].media1.filename + '/m/filters:quality(10)'))+" class=\"vlazy proyecto-img\" data-v-4a7b4c04>")]),_vm._ssrNode(" "),_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"proyecto_media proyecto_media_2",attrs:{"id":("proyecto_" + (_vm.proyecto.slug) + "_media_2")}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",_vm.proyecto.content.home[0].media2.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.proyecto.content.home[0].media2.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.proyecto.content.home[0].media2.filename + '/m/filters:quality(10)'))+" class=\"vlazy proyecto-img\" data-v-4a7b4c04>")]),_vm._ssrNode(" "),_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"proyecto_media proyecto_media_3",attrs:{"id":("proyecto_" + (_vm.proyecto.slug) + "_media_3")}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",_vm.proyecto.content.home[0].media3.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.proyecto.content.home[0].media3.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.proyecto.content.home[0].media3.filename + '/m/filters:quality(10)'))+" class=\"vlazy proyecto-img\" data-v-4a7b4c04>")]),_vm._ssrNode(" <div class=\"bg\" data-v-4a7b4c04></div>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Tipo.vue?vue&type=template&id=4a7b4c04&scoped=true&

// EXTERNAL MODULE: ./node_modules/gsap/dist/gsap.js
var gsap = __webpack_require__(7);

// EXTERNAL MODULE: external "vuex"
var external_vuex_ = __webpack_require__(6);

// CONCATENATED MODULE: ./mixins/proyectos.js

 // import Intersect from 'vue-intersect'

/* harmony default export */ var proyectos = ({
  data() {
    return {
      ready: false,
      tl_images_play: false,
      tl_images: null,
      tl_bkg: null,
      tl_hover: null,
      tl_hover_mobile: null
    };
  },

  beforeMount() {
    this.tl_images = null;
    this.tl_bkg = null;
    this.tl_hover = null;
    this.tl_hover_mobile = null;
  },

  computed: {
    intro() {
      return this.proyecto.content.intro ? this.$storyapi.richTextResolver.render(this.proyecto.content.intro) : '';
    },

    ...Object(external_vuex_["mapGetters"])({
      home: 'app/getHome',
      proyectoMobile: 'app/getMobileProyecto'
    })
  },

  // components: {
  //   Intersect,
  // },
  mounted() {
    console.log(`%c 🗂️ PROYECTOS -> mounted \n ${this.proyecto.name}`, `background:${this.proyecto.content.colores[0].fondo.color}; color: ${this.proyecto.content.colores[0].texto.color}`);
    this.$Lazyload.$on('loading', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        if (el.classList.contains('proyecto-img')) {
          window.dispatchEvent(new Event('resize'));
        }
      }
    });
    this.$Lazyload.$on('loaded', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        if (el.classList.contains('proyecto-img')) {
          window.dispatchEvent(new Event('resize'));
        }
      }
    }); // INICIANDO TIMELINES

    this.tl_images = gsap["gsap"].timeline({
      paused: true,
      ease: gsap["Power4"].easeInOut,
      delay: 0.1,
      repeat: 0,
      onStart: () => {
        console.log('🗂️ PROYECTOS -> tl_images -> onStart', this.proyecto.name);
      },
      onComplete: () => {
        console.log('🗂️ PROYECTOS -> tl_images -> onComplete', this.proyecto.name);
      }
    });
    this.tl_bkg = gsap["gsap"].timeline({
      paused: true,
      ease: gsap["Power4"].easeInOut
    });
    this.tl_hover = gsap["gsap"].timeline({
      paused: true,
      ease: gsap["Power2"].easeInOut,
      onStart: () => {},
      onComplete: () => {}
    });
    this.tl_hover_mobile = gsap["gsap"].timeline({
      paused: true,
      delay: 2,
      ease: gsap["Power2"].easeInOut
    }); // Si el texto no existe

    if (this.home.texto === null) {
      this.$store.subscribe((mutation, state) => {
        if (mutation.type === 'app/setHome') {
          if (window.innerWidth >= 768) {
            console.log(`%c PROYECTOS -> initTimeline vuex \n ${this.proyecto.name}`, `background:${this.proyecto.content.colores[0].fondo.color}; color: ${this.proyecto.content.colores[0].texto.color}`);
            this.initTimelines();
          } else {
            this.initTimelinesMobile();
          }
        }
      });
    } else if (window.innerWidth >= 768) {
      console.log(`%c PROYECTOS -> initTimeline normal \n ${this.proyecto.name}`, `background:${this.proyecto.content.colores[0].fondo.color}; color: ${this.proyecto.content.colores[0].texto.color}`);
      this.initTimelines();
    } else {
      this.initTimelinesMobile();
    }

    this.observer = new MutationObserver(mutations => {
      for (const m of mutations) {
        const newValue = m.target.getAttribute(m.attributeName);
        this.$nextTick(() => {
          this.onClassChange(newValue, m.oldValue);
        });
      }
    });
    const elemt = document.getElementById('proyecto_' + this.proyecto.slug);
    this.observer.observe(elemt, {
      attributes: true,
      attributeOldValue: true,
      attributeFilter: ['class']
    });
    this.onClassChange(elemt.getAttribute('class'));
  },

  destroyed() {},

  beforeDestroy() {
    console.log('PROYECTOS -> destroyed', this.proyecto.slug);
    this.tl_hover.kill();
    this.tl_hover_mobile.kill();
    this.tl_images.kill();
    this.observer.disconnect();
  },

  methods: { ...Object(external_vuex_["mapMutations"])({
      setMobileProyecto: 'app/setMobileProyecto'
    }),

    handlerHoverMobileProyecto(entries, observer, isIntersecting, ratio) {
      console.log('👓', this.proyecto.name, ' handlerHANDLER', isIntersecting);
      this.hoverMobileProyecto(isIntersecting);
    },

    handlerShowProy(entries, observer, isIntersecting, ratio) {
      console.log('👓', this.proyecto.name, 'handlerShowProy HANDLER', isIntersecting);

      if (isIntersecting) {
        this.showProy();
      }
    },

    testload() {},

    onClassChange(classAttrValue) {// const classList = classAttrValue.split(' ')
      // console.log(
      //   '🗂️ PROYECTOS -> onClassChange',
      //   this.proyecto.content.nombre,
      //   classList
      // )
      // if (classList.includes('is-inview')) {
      //   if (this.ready) {
      //     return
      //   }
      //   this.ready = true
      //   if (!this.tl_images_play) {
      //     this.tl_images.play()
      //     this.tl_images_play = true
      //   }
      // }
    },

    showProy() {
      const el = document.getElementById(`proyecto_${this.proyecto.slug}_media_1`);
      const opacity = el.style.opacity;
      const played = el.dataset.played;
      console.log('🗂️ PROYECTOS -> showProy', this.proyecto.content.nombre, opacity, played);

      if (opacity === '0' && played === '0') {
        el.dataset.played = '1';
        this.tl_images.restart();
      }
    },

    hoverProyecto(e, est) {
      console.log('🗂️ PROYECTOS -> hoverProyecto', this.proyecto.name, Math.random(), est, e.target); // this.tl_hover.reversed() ? this.tl_hover.timeScale(1).play() : this.tl_hover.timeScale(2).reverse()

      if (est) {
        this.tl_hover.timeScale(1).play();
      } else {
        this.tl_hover.pause().timeScale(2).reverse();
      }
    },

    hoverMobileProyecto(est) {
      if (window.innerWidth < 768) {
        console.log('🗂️ PROYECTOS -> hoverMobileProyecto', this.proyecto.name);

        if (est) {
          this.tl_hover_mobile.timeScale(1).play();
          this.setMobileProyecto(this.proyecto.name);
        } else {
          this.tl_hover_mobile.pause().timeScale(2).reverse();
        }
      }
    },

    hoverFinish() {
      this.tl_hover.restart().kill();
      this.tl_images.kill();
    },

    initTimelinesMobile() {
      console.log('🗂️ PROYECTOS -> initTimelinesMobile', this.proyecto.slug);
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug + ' .bg', {
        background: this.proyecto.content.colores[0].fondo.color
      });
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug, {
        color: this.proyecto.content.colores[0].texto.color
      });
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug + ' .proyecto_data .anim_proy', {
        color: this.proyecto.content.colores[0].texto.color
      });
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug + ' .proyecto_arrow ', {
        stroke: this.proyecto.content.colores[0].texto.color
      });
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug + ' .proyecto_title .proyecto_title_int span', {
        color: this.proyecto.content.colores[0].nombre.color
      });
      gsap["gsap"].set('#proyecto_' + this.proyecto.slug + ' .proyecto_title .proyecto_title_int', {
        color: this.proyecto.content.colores[0].nombre.color
      }); // this.tl_hover_mobile.fromTo(
      //   '#proyecto_' + this.proyecto.slug + ' .proyecto_media',
      //   {
      //     opacity: 1,
      //     y: 0,
      //     x: 0,
      //     scale: 1,
      //   },
      //   {
      //     opacity: 0.2,
      //     x: '60vw',
      //     y: '5vh',
      //     scale: 0.8,
      //     duration: 0.7,
      //     ease: Sine.easeInOut,
      //     stagger: {
      //       each: 0.1,
      //       from: 'center',
      //     },
      //   },
      //   '-=0.2'
      // )
      // this.tl_hover_mobile.fromTo(
      //   '#proyecto_' + this.proyecto.slug + ' .proyecto_data',
      //   {
      //     clipPath: 'inset(0% 100% 0% 0%)',
      //     // webkitClipPath: 'inset(0% 100% 0% 0%)',
      //   },
      //   {
      //     clipPath: 'inset(0% 0% 0% 0%)',
      //     // webkitClipPath: 'inset(0% 0% 0% 0%)',
      //   },
      //   '-=0.4'
      // )
      // ANIMANDO LA INFO
      // this.tl_hover_mobile.fromTo(
      //   '#proyecto_' + this.proyecto.slug + ' .proyecto_data .anim_proy',
      //   { y: '50vh' },
      //   {
      //     y: 0,
      //     duration: 0.4,
      //     stagger: {
      //       // from: 'random',
      //       each: 0.1,
      //     },
      //   },
      //   '-=0.4'
      // )
      // ANIMANDO EL TITULO
      // this.tl_hover_mobile.fromTo(
      //   '#proyecto_' +
      //     this.proyecto.slug +
      //     ' .proyecto_title .proyecto_title_int span',
      //   {
      //     // '--font-width': 80,
      //     scaleY: 1,
      //     autoAlpha: 0,
      //   },
      //   {
      //     // '--font-width': 120,
      //     scaleY: 1,
      //     autoAlpha: 1,
      //     duration: 0.5,
      //     stagger: {
      //       // from: 'random',
      //       each: 0.1,
      //     },
      //   },
      //   '-=0.3'
      // )

      this.tl_images.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_media', {
        // clipPath: 'inset(0% 0% 100% 0%)',
        scaleY: 1.1,
        autoAlpha: 0
      }, {
        // clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',
        scaleY: 1,
        autoAlpha: 1,
        duration: 1,
        stagger: {
          each: 0.2 // from: 'edges',

        },
        ease: gsap["Power2"].easeInOut,
        onComplete: () => {
          this.observer.disconnect();
        }
      });
      this.tl_images.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_data_int', {
        y: -10,
        autoAlpha: 0 // clipPath: 'inset(0% 100% 0% 0%)',
        // webkitClipPath: 'inset(0% 100% 0% 0%)',

      }, {
        y: 0,
        autoAlpha: 1 // clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',

      }, '-=0.4');
    },

    initTimelines() {
      console.log('🗂️ PROYECTOS -> initTimelines', this.proyecto.name, this.home.fondo);
      gsap["gsap"].set('body', {
        background: this.home.fondo
      });
      this.tl_hover.fromTo('body', {
        background: this.home.fondo
      }, {
        background: this.proyecto.content.colores[0].fondo.color,
        duration: 0.4
      });
      this.tl_hover.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_media', {
        opacity: 1,
        y: 30,
        x: 0,
        scale: 1,
        skewX: 0,
        skewY: 0,
        rotationY: 0,
        rotation: 0
      }, {
        opacity: 0.2,
        y: '10vh',
        x: '30vw',
        scale: 0.8,
        skewX: 0,
        skewY: 0,
        rotationY: 0,
        rotation: 0,
        duration: 0.7,
        ease: gsap["Sine"].easeInOut,
        stagger: {
          each: 0.1,
          from: 'center'
        }
      }, '-=0.2');
      this.tl_hover.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_data .anim_proy', {
        color: this.home.texto,
        x: 0
      }, {
        color: this.proyecto.content.colores[0].texto.color,
        x: 20,
        duration: 0.4,
        stagger: {
          // from: 'random',
          each: 0.1
        }
      }, '-=0.4');
      this.tl_hover.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_arrow ', {
        stroke: 'transparent',
        opacity: 0,
        x: '-20vw',
        y: '20vh'
      }, {
        stroke: this.proyecto.content.colores[0].texto.color,
        x: 0,
        y: 0,
        opacity: 0.4,
        duration: 0.4,
        stagger: {
          // from: 'random',
          each: 0.02
        }
      }, '-=0.4');
      this.tl_hover.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_title .proyecto_title_int_cliente', {
        // '--font-width': 80,
        clipPath: 'inset(0% 100% 0% 0%)',
        // webkitClipPath: 'inset(0% 100% 0% 0%)',
        scaleY: 1.2,
        autoAlpha: 0,
        color: this.home.fondo
      }, {
        // '--font-width': 120,
        clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',
        scaleY: 1,
        autoAlpha: 1,
        duration: 0.5,
        color: this.proyecto.content.colores[0].nombre.color
      }, '-=0.3');
      this.tl_hover.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_title .proyecto_title_int span', {
        // '--font-width': 80,
        clipPath: 'inset(0% 100% 0% 0%)',
        // webkitClipPath: 'inset(0% 100% 0% 0%)',
        scaleY: 1.2,
        autoAlpha: 0,
        color: this.home.fondo
      }, {
        // '--font-width': 120,
        clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',
        scaleY: 1,
        autoAlpha: 1,
        duration: 0.5,
        color: this.proyecto.content.colores[0].nombre.color,
        stagger: {
          // from: 'random',
          each: 0.1
        }
      }, '-=0.3'); // gsap.set('#proyecto_' + this.proyecto.slug + ' .proyecto_media', {
      //   clipPath: 'inset(0% 0% 100% 0%)',
      //   // webkitClipPath: 'inset(0% 0% 100% 0%)',
      //   scaleY: 1.1,
      //   autoAlpha: 0,
      // })
      // IMAGENES

      this.tl_images.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_media', {
        // clipPath: 'inset(0% 0% 100% 0%)',
        scaleY: 1.1,
        autoAlpha: 0
      }, {
        // clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',
        scaleY: 1,
        autoAlpha: 1,
        duration: 1,
        stagger: {
          each: 0.2 // from: 'edges',

        },
        ease: gsap["Power2"].easeInOut,
        onComplete: () => {
          this.observer.disconnect();
        }
      });
      this.tl_images.fromTo('#proyecto_' + this.proyecto.slug + ' .proyecto_data_int', {
        y: -10,
        autoAlpha: 0 // clipPath: 'inset(0% 100% 0% 0%)',
        // webkitClipPath: 'inset(0% 100% 0% 0%)',

      }, {
        y: 0,
        autoAlpha: 1 // clipPath: 'inset(0% 0% 0% 0%)',
        // webkitClipPath: 'inset(0% 0% 0% 0%)',

      }, '-=0.4');
    },

    loaded(e) {
      if (window) {
        if (!e.target.classList.contains('isLoaded') && !e.target.classList.contains('isLoading')) {
          const parent = e.target.parentElement;
          gsap["gsap"].set(parent, {
            autoAlpha: 0
          });
        } else {
          window.dispatchEvent(new Event('resize'));
        }
      }
    }

  }
});
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Tipo.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Tipovue_type_script_lang_js_ = ({
  components: {},
  mixins: [proyectos],
  props: {
    proyecto: {
      type: Object,
      default: null
    },
    par: {
      type: Boolean,
      default: null
    }
  },
  methods: {
    toProject() {
      this.$router.push({
        path: '/' + this.proyecto.full_slug
      });
    }

  }
});
// CONCATENATED MODULE: ./components/proyectos/Tipo.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Tipovue_type_script_lang_js_ = (Tipovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Tipo.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(106)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Tipovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "4a7b4c04",
  "73624dda"
  
)

/* harmony default export */ var Tipo = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 95:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(107);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("c9b79812", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=proyectos-tipo.js.map