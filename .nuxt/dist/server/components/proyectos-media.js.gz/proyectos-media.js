exports.ids = [13,14,15,16,17,18,19];
exports.modules = {

/***/ 100:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(119);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("f2a9c556", content, true, context)
};

/***/ }),

/***/ 101:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(121);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("504510f2", content, true, context)
};

/***/ }),

/***/ 102:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(123);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("120c4426", content, true, context)
};

/***/ }),

/***/ 103:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(125);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("d8facbc0", content, true, context)
};

/***/ }),

/***/ 114:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_video_vue_vue_type_style_index_0_id_03da436c_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 115:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_video[data-v-03da436c]{display:grid;grid-template-columns:repeat(5, minmax(0, 1fr));}.media_video .media_video_wrapper[data-v-03da436c]{padding-top:56%}.media_video .media_video_wrapper[data-v-03da436c]{position:relative;}.media_video .media_video_wrapper[data-v-03da436c]{height:0px;}.media_video .media_video_wrapper[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper[data-v-03da436c]{align-self:center;}.media_video .media_video_wrapper.center[data-v-03da436c]{grid-column:1 / -1;}.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column-start:1;}}@media (min-width: 768px){.media_video .media_video_wrapper.left[data-v-03da436c]{grid-column-end:5;}}.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{order:2;}}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column-start:2;}}@media (min-width: 768px){.media_video .media_video_wrapper.right[data-v-03da436c]{grid-column-end:6;}}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{position:absolute;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{top:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{right:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{left:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{bottom:0px;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{display:inline-block;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{height:100%;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper .media_video_player[data-v-03da436c]{-o-object-fit:contain;object-fit:contain;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{background-position:50% 50%;background-size:100% 100%;transition:opacity .8s,height 0s;transition-delay:0s,0s}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{position:absolute;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{top:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{right:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{left:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{bottom:0px;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{height:100%;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{width:100%;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{cursor:pointer;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{overflow:hidden;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{border-style:none;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{background-size:cover;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{font-size:0.875rem;line-height:1.25rem;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{opacity:1;}.media_video .media_video_wrapper .media_video_poster[data-v-03da436c]{outline:2px solid transparent;outline-offset:2px;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-variation-settings:\"wght\" 100,\"wdth\" 80,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,100),\"wdth\" var(--font-width,80),\"ital\" 0}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-size:6rem;line-height:1;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{letter-spacing:-0.05em;}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{--tw-text-opacity:1;color:rgba(255, 255, 255, var(--tw-text-opacity));}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{--tw-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.05);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);}.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{transition-property:all;transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transition-duration:150ms;}@media (min-width: 768px){.media_video .media_video_wrapper .media_video_poster b[data-v-03da436c]{font-size:8rem;line-height:1;}}.media_video .media_video_wrapper .media_video_poster b i[data-v-03da436c]{font-size:1.5rem;line-height:2rem;}@media (min-width: 768px){.media_video .media_video_wrapper .media_video_poster b i[data-v-03da436c]{font-size:3.75rem;line-height:1;}}.media_video .media_video_wrapper .media_video_poster.dif b span[data-v-03da436c]{position:relative;-webkit-mix-blend-mode:overlay;-moz-mix-blend-mode:overlay;-o-mix-blend-mode:overlay;-ms-mix-blend-mode:overlay;mix-blend-mode:overlay}.media_video .media_video_wrapper .media_video_poster:hover b[data-v-03da436c]{font-variation-settings:\"wght\" 400,\"wdth\" 120,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,400),\"wdth\" var(--font-width,120),\"ital\" 0}.media_video .media_video_content[data-v-03da436c]{margin-top:2rem;margin-bottom:2rem;}.media_video .media_video_content[data-v-03da436c]{align-self:center;}.media_video .media_video_content.center[data-v-03da436c]{grid-column-start:3;}.media_video .media_video_content.center[data-v-03da436c]{grid-column-end:6;}.media_video .media_video_content.left[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{grid-column-start:5;}}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{grid-column-end:6;}}@media (min-width: 768px){.media_video .media_video_content.left[data-v-03da436c]{padding:2rem;}}.media_video .media_video_content.right[data-v-03da436c]{grid-column:1 / -1;}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{order:1;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{grid-column-start:1;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{grid-column-end:2;}}@media (min-width: 768px){.media_video .media_video_content.right[data-v-03da436c]{padding:2rem;}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 116:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_carrusel_vue_vue_type_style_index_0_lang_postcss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_carrusel_vue_vue_type_style_index_0_lang_postcss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_carrusel_vue_vue_type_style_index_0_lang_postcss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_carrusel_vue_vue_type_style_index_0_lang_postcss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_carrusel_vue_vue_type_style_index_0_lang_postcss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 117:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_carrusel{width:100%;}.flux-pagination li{display:block;margin:0 1% 1.5%;cursor:pointer;width:1%!important;height:0;min-width:5px!important;min-height:5px!important;padding-bottom:1%!important;position:relative;}.flux-pagination li .pagination-item{position:absolute;top:0;left:0;right:0;bottom:0;border:1px solid #fff;border-radius:50%;background-color:rgba(0,0,0,.7);transition:background-color .2s ease-in,border .2s ease-in}.flux-pagination li .pagination-item.active{border-color:#fff;background-color:#fff}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 118:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_sobrepuestas_vue_vue_type_style_index_0_id_631c3c7a_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(100);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_sobrepuestas_vue_vue_type_style_index_0_id_631c3c7a_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_sobrepuestas_vue_vue_type_style_index_0_id_631c3c7a_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_sobrepuestas_vue_vue_type_style_index_0_id_631c3c7a_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_sobrepuestas_vue_vue_type_style_index_0_id_631c3c7a_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 119:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_sobrepuestas[data-v-631c3c7a]{display:flex;width:100%;flex-direction:column}@media (min-width: 768px){.media_sobrepuestas[data-v-631c3c7a]{flex-direction:row}}.media_sobrepuestas.p-items-center[data-v-631c3c7a]{align-items:center}.media_sobrepuestas.p-items-baseline[data-v-631c3c7a]{align-items:baseline}.media_sobrepuestas.p-items-start[data-v-631c3c7a]{align-items:flex-start}.media_sobrepuestas .img-wrapper[data-v-631c3c7a]{margin-bottom:2rem}.media_sobrepuestas .img-wrapper[data-v-631c3c7a]{padding-left:0px;padding-right:0px}@media (min-width: 768px){.media_sobrepuestas .img-wrapper[data-v-631c3c7a]{padding-left:2rem;padding-right:2rem}}.media_sobrepuestas .img-wrapper img[data-v-631c3c7a]{margin-top:2rem;margin-bottom:2rem}.media_sobrepuestas .img-wrapper img[data-v-631c3c7a]{display:block}.media_sobrepuestas .img-wrapper img[data-v-631c3c7a]{width:100%}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 120:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_derecha_vue_vue_type_style_index_0_id_1207e388_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(101);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_derecha_vue_vue_type_style_index_0_id_1207e388_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_derecha_vue_vue_type_style_index_0_id_1207e388_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_derecha_vue_vue_type_style_index_0_id_1207e388_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_derecha_vue_vue_type_style_index_0_id_1207e388_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 121:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_derecha[data-v-1207e388]{display:flex;width:100%;flex-direction:column;align-items:center}@media (min-width: 768px){.media_derecha[data-v-1207e388]{flex-direction:row-reverse}}.media_derecha.pleft .descripcion[data-v-1207e388]{flex-shrink:1}@media (min-width: 768px){.media_derecha.pleft .descripcion[data-v-1207e388]{margin-left:6rem}}.media_derecha.pright .descripcion[data-v-1207e388]{flex-shrink:1}@media (min-width: 768px){.media_derecha.pright .descripcion[data-v-1207e388]{margin-right:6rem}}@media (min-width: 768px){.media_derecha .p80[data-v-1207e388]{width:80%}}@media (min-width: 768px){.media_derecha .p60[data-v-1207e388]{width:60%}}@media (min-width: 768px){.media_derecha .p50[data-v-1207e388]{width:50%}}@media (min-width: 768px){.media_derecha .p40[data-v-1207e388]{width:40%}}@media (min-width: 768px){.media_derecha .p20[data-v-1207e388]{width:20%}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 122:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_full_vue_vue_type_style_index_0_id_3b0bbaab_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(102);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_full_vue_vue_type_style_index_0_id_3b0bbaab_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_full_vue_vue_type_style_index_0_id_3b0bbaab_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_full_vue_vue_type_style_index_0_id_3b0bbaab_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_full_vue_vue_type_style_index_0_id_3b0bbaab_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 123:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_full[data-v-3b0bbaab]{display:flex;width:100%;flex-direction:column;align-items:center}@media (min-width: 768px){.media_full[data-v-3b0bbaab]{flex-direction:row}}.media_full .img-wrapper[data-v-3b0bbaab]{margin-bottom:2rem}.media_full .img-wrapper[data-v-3b0bbaab]{padding-left:0px;padding-right:0px}@media (min-width: 768px){.media_full .img-wrapper[data-v-3b0bbaab]{padding-left:2rem;padding-right:2rem}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 124:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_broken_vue_vue_type_style_index_0_id_45fa9d9f_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(103);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_broken_vue_vue_type_style_index_0_id_45fa9d9f_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_broken_vue_vue_type_style_index_0_id_45fa9d9f_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_broken_vue_vue_type_style_index_0_id_45fa9d9f_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_broken_vue_vue_type_style_index_0_id_45fa9d9f_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 125:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media_broken[data-v-45fa9d9f]{display:grid;width:100%;grid-template-columns:repeat(1, minmax(0, 1fr))}@media (min-width: 768px){.media_broken[data-v-45fa9d9f]{grid-template-columns:repeat(12, minmax(0, 1fr))}.media_broken[data-v-45fa9d9f]{grid-template-rows:repeat(1, minmax(0, 1fr))}}.media_broken.pgap-1[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-1[data-v-45fa9d9f]{gap:0.25rem}}.media_broken.pgap-2[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-2[data-v-45fa9d9f]{gap:0.5rem}}.media_broken.pgap-3[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-3[data-v-45fa9d9f]{gap:0.75rem}}.media_broken.pgap-4[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-4[data-v-45fa9d9f]{gap:1rem}}.media_broken.pgap-5[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-5[data-v-45fa9d9f]{gap:1.25rem}}.media_broken.pgap-6[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-6[data-v-45fa9d9f]{gap:1.5rem}}.media_broken.pgap-7[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-7[data-v-45fa9d9f]{gap:1.75rem}}.media_broken.pgap-8[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-8[data-v-45fa9d9f]{gap:2rem}}.media_broken.pgap-9[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-9[data-v-45fa9d9f]{gap:2.25rem}}.media_broken.pgap-10[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-10[data-v-45fa9d9f]{gap:2.5rem}}.media_broken.pgap-11[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-11[data-v-45fa9d9f]{gap:2.75rem}}.media_broken.pgap-12[data-v-45fa9d9f]{gap:0px}@media (min-width: 768px){.media_broken.pgap-12[data-v-45fa9d9f]{gap:3rem}}.media_broken .item[data-v-45fa9d9f]{grid-row:auto}.media_broken .item[data-v-45fa9d9f]{margin-bottom:2rem}@media (min-width: 768px){.media_broken .item[data-v-45fa9d9f]{grid-row:1 / -1}}.media_broken .item.pz-0[data-v-45fa9d9f]{z-index:0}.media_broken .item.pz-10[data-v-45fa9d9f]{z-index:10}.media_broken .item.pz-20[data-v-45fa9d9f]{z-index:20}.media_broken .item.pz-30[data-v-45fa9d9f]{z-index:30}.media_broken .item.pz-40[data-v-45fa9d9f]{z-index:40}.media_broken .item.pz-50[data-v-45fa9d9f]{z-index:50}.media_broken .item.s-1[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-1[data-v-45fa9d9f]{grid-column-start:1}}.media_broken .item.s-2[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-2[data-v-45fa9d9f]{grid-column-start:2}}.media_broken .item.s-3[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-3[data-v-45fa9d9f]{grid-column-start:3}}.media_broken .item.s-4[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-4[data-v-45fa9d9f]{grid-column-start:4}}.media_broken .item.s-5[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-5[data-v-45fa9d9f]{grid-column-start:5}}.media_broken .item.s-6[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-6[data-v-45fa9d9f]{grid-column-start:6}}.media_broken .item.s-7[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-7[data-v-45fa9d9f]{grid-column-start:7}}.media_broken .item.s-8[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-8[data-v-45fa9d9f]{grid-column-start:8}}.media_broken .item.s-9[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-9[data-v-45fa9d9f]{grid-column-start:9}}.media_broken .item.s-10[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-10[data-v-45fa9d9f]{grid-column-start:10}}.media_broken .item.s-11[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-11[data-v-45fa9d9f]{grid-column-start:11}}.media_broken .item.s-12[data-v-45fa9d9f]{grid-column-start:1}@media (min-width: 768px){.media_broken .item.s-12[data-v-45fa9d9f]{grid-column-start:12}}.media_broken .item.e-1[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-1[data-v-45fa9d9f]{grid-column-end:1}}.media_broken .item.e-2[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-2[data-v-45fa9d9f]{grid-column-end:2}}.media_broken .item.e-3[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-3[data-v-45fa9d9f]{grid-column-end:3}}.media_broken .item.e-4[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-4[data-v-45fa9d9f]{grid-column-end:4}}.media_broken .item.e-5[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-5[data-v-45fa9d9f]{grid-column-end:5}}.media_broken .item.e-6[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-6[data-v-45fa9d9f]{grid-column-end:6}}.media_broken .item.e-7[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-7[data-v-45fa9d9f]{grid-column-end:7}}.media_broken .item.e-8[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-8[data-v-45fa9d9f]{grid-column-end:8}}.media_broken .item.e-9[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-9[data-v-45fa9d9f]{grid-column-end:9}}.media_broken .item.e-10[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-10[data-v-45fa9d9f]{grid-column-end:10}}.media_broken .item.e-11[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-11[data-v-45fa9d9f]{grid-column-end:11}}.media_broken .item.e-12[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-12[data-v-45fa9d9f]{grid-column-end:12}}.media_broken .item.e-13[data-v-45fa9d9f]{grid-column-end:2}@media (min-width: 768px){.media_broken .item.e-13[data-v-45fa9d9f]{grid-column-end:13}}.media_broken .item.sp-1[data-v-45fa9d9f]{grid-column:span 1 / span 1}.media_broken .item.sp-2[data-v-45fa9d9f]{grid-column:span 2 / span 2}.media_broken .item.sp-3[data-v-45fa9d9f]{grid-column:span 3 / span 3}.media_broken .item.sp-4[data-v-45fa9d9f]{grid-column:span 4 / span 4}.media_broken .item.sp-5[data-v-45fa9d9f]{grid-column:span 5 / span 5}.media_broken .item.sp-6[data-v-45fa9d9f]{grid-column:span 6 / span 6}.media_broken .item.sp-7[data-v-45fa9d9f]{grid-column:span 7 / span 7}.media_broken .item.sp-8[data-v-45fa9d9f]{grid-column:span 8 / span 8}.media_broken .item.sp-9[data-v-45fa9d9f]{grid-column:span 9 / span 9}.media_broken .item.sp-10[data-v-45fa9d9f]{grid-column:span 10 / span 10}.media_broken .item.sp-11[data-v-45fa9d9f]{grid-column:span 11 / span 11}.media_broken .item.sp-12[data-v-45fa9d9f]{grid-column:span 12 / span 12}@media (min-width: 768px){.media_broken .item.pm-0[data-v-45fa9d9f]{margin-bottom:0px}}@media (min-width: 768px){.media_broken .item.pm-2[data-v-45fa9d9f]{margin-bottom:1.5rem}}@media (min-width: 768px){.media_broken .item.pm-4[data-v-45fa9d9f]{margin-bottom:2rem}}@media (min-width: 768px){.media_broken .item.pm-6[data-v-45fa9d9f]{margin-bottom:2.5rem}}@media (min-width: 768px){.media_broken .item.pm-8[data-v-45fa9d9f]{margin-bottom:3rem}}@media (min-width: 768px){.media_broken .item.pm-10[data-v-45fa9d9f]{margin-bottom:3.5rem}}@media (min-width: 768px){.media_broken .item.pm-12[data-v-45fa9d9f]{margin-bottom:4rem}}@media (min-width: 768px){.media_broken .item.pm-14[data-v-45fa9d9f]{margin-bottom:5rem}}@media (min-width: 768px){.media_broken .item.pm-16[data-v-45fa9d9f]{margin-bottom:6rem}}@media (min-width: 768px){.media_broken .item.pm-18[data-v-45fa9d9f]{margin-bottom:7rem}}@media (min-width: 768px){.media_broken .item.pm-20[data-v-45fa9d9f]{margin-bottom:8rem}}@media (min-width: 768px){.media_broken .item.pt-0[data-v-45fa9d9f]{margin-top:0px}}@media (min-width: 768px){.media_broken .item.pt-2[data-v-45fa9d9f]{margin-top:1.5rem}}@media (min-width: 768px){.media_broken .item.pt-4[data-v-45fa9d9f]{margin-top:2rem}}@media (min-width: 768px){.media_broken .item.pt-6[data-v-45fa9d9f]{margin-top:2.5rem}}@media (min-width: 768px){.media_broken .item.pt-8[data-v-45fa9d9f]{margin-top:3rem}}@media (min-width: 768px){.media_broken .item.pt-10[data-v-45fa9d9f]{margin-top:3.5rem}}@media (min-width: 768px){.media_broken .item.pt-12[data-v-45fa9d9f]{margin-top:4rem}}@media (min-width: 768px){.media_broken .item.pt-14[data-v-45fa9d9f]{margin-top:5rem}}@media (min-width: 768px){.media_broken .item.pt-16[data-v-45fa9d9f]{margin-top:6rem}}@media (min-width: 768px){.media_broken .item.pt-18[data-v-45fa9d9f]{margin-top:7rem}}@media (min-width: 768px){.media_broken .item.pt-20[data-v-45fa9d9f]{margin-top:8rem}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 126:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(146);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("cd196078", content, true, context)
};

/***/ }),

/***/ 133:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_video.vue?vue&type=template&id=03da436c&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"media_video"},[_vm._ssrNode("<div"+(_vm._ssrClass(null,("media_video_wrapper " + (_vm.media.posicion))))+" data-v-03da436c>","</div>",[_c('video',{directives:[{name:"intersection",rawName:"v-intersection",value:(_vm.handlerStopVideo),expression:"handlerStopVideo"}],ref:("video_" + (_vm.media._uid)),staticClass:"media_video_player",attrs:{"loading":"lazy","controls":"","src":_vm.media.video.filename,"preload":"auto","poster":_vm.media.poster.filename + '/m/'}},[]),_vm._ssrNode(" "),_c('button',{directives:[{name:"cursor-right",rawName:"v-cursor-right"},{name:"lazy-background",rawName:"v-lazy-background"}],staticClass:"media_video_poster dif",attrs:{"id":("video_btn_" + (_vm.media._uid)),"lazy-background":_vm.media.poster.filename + '/m/'},on:{"click":_vm.playVideo}},[_vm._ssrNode("<b class=\"t proy_link btn-mbp hvr-sweep-to-top\" data-v-03da436c><span data-v-03da436c> Play <i class=\"fal fa-play\" data-v-03da436c></i></span></b>")])],2),_vm._ssrNode(" "),(_vm.showdesc)?[_vm._ssrNode(((_vm.media.descripcion)?("<div"+(_vm._ssrClass(null,("descripcion media_video_content " + (_vm.media.posicion))))+" data-v-03da436c>"+(_vm._s(_vm.$storyapi.richTextResolver.render(_vm.media.descripcion)))+"</div>"):"<!---->"))]:_vm._e()],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_video.vue?vue&type=template&id=03da436c&scoped=true&

// EXTERNAL MODULE: ./node_modules/gsap/dist/gsap.js
var gsap = __webpack_require__(7);

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_video.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Media_videovue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {
      showdesc: true
    };
  },

  mounted() {
    console.log('VIEDO', this.$storyapi.richTextResolver.render(this.media.descripcion));

    if (this.$storyapi.richTextResolver.render(this.media.descripcion) === '<p></p>') {
      this.showdesc = false;
    }
  },

  methods: {
    playVideo(e) {
      this.$refs[`video_${this.media._uid}`].play();
      gsap["gsap"].to(`#video_btn_${this.media._uid}`, {
        //   clipPath: 'inset(0% 0% 0% 0%)',
        autoAlpha: 0,
        duration: 1,
        onComplete: () => {},
        ease: gsap["Expo"].easeInOut
      });
    },

    stopVideo() {
      const videop = this.$refs[`video_${this.media._uid}`];
      videop.pause();
      videop.currentTime = 0;
      gsap["gsap"].to(`#video_btn_${this.media._uid}`, {
        //   clipPath: 'inset(0% 0% 0% 0%)',
        autoAlpha: 1,
        duration: 0.5,
        onComplete: () => {},
        ease: gsap["Expo"].easeInOut
      });
    },

    handlerStopVideo(e, observer, isIntersecting, ratio) {
      if (!isIntersecting) this.stopVideo();
    }

  }
});
// CONCATENATED MODULE: ./components/proyectos/Media_video.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_videovue_type_script_lang_js_ = (Media_videovue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_video.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(114)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_videovue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "03da436c",
  "7913212a"
  
)

/* harmony default export */ var Media_video = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 134:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_carrusel.vue?vue&type=template&id=cf528fb8&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"media_carrusel"},[_c('vue-flux',{ref:"slider",attrs:{"options":_vm.vfOptions,"images":_vm.vfImages,"transitions":_vm.vfTransitions},scopedSlots:_vm._u([{key:"controls",fn:function(){return [_c('flux-controls')]},proxy:true},{key:"pagination",fn:function(){return [_c('flux-pagination')]},proxy:true}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_carrusel.vue?vue&type=template&id=cf528fb8&

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_carrusel.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Media_carruselvue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {
      vfOptions: {
        autoplay: true
      },
      vfImages: this.media.imagenes.map(x => {
        return x.filename;
      }),
      vfTransitions: [{
        name: 'swipe',
        options: {
          totalDuration: 800,
          easing: 'ease-in-out'
        }
      }]
    };
  },

  mounted() {
    if (window) {
      window.dispatchEvent(new Event('resize'));
    }
  }

});
// CONCATENATED MODULE: ./components/proyectos/Media_carrusel.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_carruselvue_type_script_lang_js_ = (Media_carruselvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_carrusel.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(116)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_carruselvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "51f433f8"
  
)

/* harmony default export */ var Media_carrusel = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 135:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_sobrepuestas.vue?vue&type=template&id=631c3c7a&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{class:("media_sobrepuestas p-" + (_vm.media.alinear))},_vm._l((_vm.media.imagen),function(imagen,index){return _c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],key:index,class:("img-wrapper " + (index === 0 ? ("md:" + (_vm.media.ancho)) : 'md:flex-shrink')),attrs:{"data-scroll":"","data-scroll-speed":!_vm.$isMobile() ? ("" + (index === 0 ? -1 : 0.3)) : 0}},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",imagen.filename + '/m/'))+(_vm._ssrAttr("data-loading",imagen.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",imagen.filename + '/m/filters:quality(10)'))+" alt=\"Melborp\" class=\"vlazy\" data-v-631c3c7a>")])}),0)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_sobrepuestas.vue?vue&type=template&id=631c3c7a&scoped=true&

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_sobrepuestas.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Media_sobrepuestasvue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {};
  }

});
// CONCATENATED MODULE: ./components/proyectos/Media_sobrepuestas.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_sobrepuestasvue_type_script_lang_js_ = (Media_sobrepuestasvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_sobrepuestas.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(118)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_sobrepuestasvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "631c3c7a",
  "66a8b9ca"
  
)

/* harmony default export */ var Media_sobrepuestas = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 136:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_derecha.vue?vue&type=template&id=1207e388&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"media_derecha",class:("p" + (_vm.media.ubicacion))},[(_vm.media.ubicacion == 'right')?[_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"flex-shrink-0",class:("p" + (_vm.media.ancho))},[_vm._ssrNode("<img data-scroll"+(_vm._ssrAttr("data-scroll-speed",!_vm.$isMobile() ? 1 : 0))+(_vm._ssrAttr("data-src",_vm.media.imagen.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.media.imagen.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.media.imagen.filename + '/m/filters:quality(10)'))+" alt=\"Melborp\" class=\"w-full vlazy\" data-v-1207e388>")]),_vm._ssrNode(" "+((_vm.media.descripcion)?("<div class=\"descripcion\" data-v-1207e388>"+(_vm._s(_vm.descripcion))+"</div>"):"<!---->"))]:[_vm._ssrNode(((_vm.media.descripcion)?("<div class=\"descripcion\" data-v-1207e388>"+(_vm._s(_vm.descripcion))+"</div>"):"<!---->")+" "),_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"flex-shrink-0",class:("p" + (_vm.media.ancho))},[_vm._ssrNode("<img data-scroll"+(_vm._ssrAttr("data-scroll-speed",!_vm.$isMobile() ? 1 : 0))+(_vm._ssrAttr("data-src",_vm.media.imagen.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.media.imagen.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.media.imagen.filename + '/m/filters:quality(10)'))+" alt=\"Melborp\" class=\"w-full vlazy\" data-v-1207e388>")])]],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_derecha.vue?vue&type=template&id=1207e388&scoped=true&

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_derecha.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Media_derechavue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },
  computed: {
    descripcion() {
      return this.media.descripcion ? this.$storyapi.richTextResolver.render(this.media.descripcion) : '';
    }

  }
});
// CONCATENATED MODULE: ./components/proyectos/Media_derecha.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_derechavue_type_script_lang_js_ = (Media_derechavue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_derecha.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(120)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_derechavue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "1207e388",
  "3a39a217"
  
)

/* harmony default export */ var Media_derecha = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 137:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_full.vue?vue&type=template&id=3b0bbaab&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],staticClass:"media_full"},[_vm._ssrNode("<img"+(_vm._ssrAttr("data-src",_vm.media.imagen.filename + '/m/'))+(_vm._ssrAttr("data-loading",_vm.media.imagen.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",_vm.media.imagen.filename + '/m/filters:quality(10)'))+" alt=\"Melborp\" class=\"vlazy media-full\" data-v-3b0bbaab>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_full.vue?vue&type=template&id=3b0bbaab&scoped=true&

// EXTERNAL MODULE: ./node_modules/gsap/dist/gsap.js
var gsap = __webpack_require__(7);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_full.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Media_fullvue_type_script_lang_js_ = ({
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {};
  },

  mounted() {
    if (window) {
      window.dispatchEvent(new Event('resize'));
    }

    this.$Lazyload.$on('loaded', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        if (el.classList.contains('media-full')) {
          gsap["gsap"].to(el, {
            // clipPath: 'inset(0% 0% 0% 0%)',
            // webkitClipPath: 'inset(0% 0% 0% 0%)',
            scaleY: 1,
            autoAlpha: 1,
            duration: 0.5,
            ease: gsap["Power2"].easeInOut,
            onStart: () => {
              window.dispatchEvent(new Event('resize'));
            }
          });
        }
      }
    });
  },

  methods: {
    loaded() {
      if (window) {
        window.dispatchEvent(new Event('resize'));
      }
    }

  }
});
// CONCATENATED MODULE: ./components/proyectos/Media_full.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_fullvue_type_script_lang_js_ = (Media_fullvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_full.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(122)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_fullvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "3b0bbaab",
  "880fd1a0"
  
)

/* harmony default export */ var Media_full = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 138:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_broken.vue?vue&type=template&id=45fa9d9f&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{class:("media_broken pgap-" + (_vm.media.gap))},[_vm._l((_vm.media.broken_item),function(item,i){return [_c('div',{directives:[{name:"lazy-container",rawName:"v-lazy-container",value:({ selector: 'img' }),expression:"{ selector: 'img' }"}],key:_vm.media._uid + '_' + i,staticClass:"item",class:item.classText,attrs:{"data-scroll":!_vm.$isMobile() ? item.parallax != 0 : null,"data-scroll-speed":!_vm.$isMobile() ? (item.parallax === 0 ? 0 : item.parallax) : null}},[_vm._ssrNode(((item.imagen.filename)?("<img"+(_vm._ssrAttr("data-src",item.imagen.filename + '/m/'))+(_vm._ssrAttr("data-loading",item.imagen.filename + '/m/filters:quality(10)'))+(_vm._ssrAttr("data-error",item.imagen.filename + '/m/filters:quality(10)'))+" alt=\"Melborp\" class=\"vlazy\" data-v-45fa9d9f>"):"<!---->")+" "+((item.descripcion != '')?("<div"+(_vm._ssrStyle(null,("font-variation-settings: 'wght' var(--font-weight, " + (item.wght) + "), 'wdth' var(--font-width, " + (item.wdth) + "), 'ital' 0;"), null))+" data-v-45fa9d9f>"+(_vm._s(_vm.$storyapi.richTextResolver.render(item.descripcion)))+"</div>"):"<!---->"))])]})],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media_broken.vue?vue&type=template&id=45fa9d9f&scoped=true&

// EXTERNAL MODULE: ./mixins/loader.js
var loader = __webpack_require__(89);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media_broken.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Media_brokenvue_type_script_lang_js_ = ({
  mixins: [loader["a" /* default */]],
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  beforeMount() {
    this.media.broken_item.forEach(item => {
      item.classes = [];

      if (item.inicio !== '') {
        item.classes.push(`s-${item.inicio}`);
      }

      if (item.fin !== '') {
        item.classes.push(`e-${item.fin}`);
      }

      if (item.ancho !== '') {
        item.classes.push(`sp-${item.ancho}`);
      }

      if (item.z_index !== '') {
        item.classes.push(`p${item.z_index}`);
      }

      if (item.ubicacion !== '') {
        item.classes.push(`${item.ubicacion}`);
      }

      if (item.size !== '') {
        item.classes.push(`${item.size}`);
      }

      if (item.abajo !== '') {
        if (!this.$isMobile()) item.classes.push(`pm-${item.abajo}`);
      }

      if (item.arriba !== '') {
        if (!this.$isMobile()) item.classes.push(`pt-${item.arriba}`);
      }

      item.classText = item.classes.join(' ');
    });
    console.log(this.media.broken_item);
  },

  mounted() {
    console.log('BROKEN', this.media);
  }

});
// CONCATENATED MODULE: ./components/proyectos/Media_broken.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Media_brokenvue_type_script_lang_js_ = (Media_brokenvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media_broken.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(124)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Media_brokenvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "45fa9d9f",
  "70631b36"
  
)

/* harmony default export */ var Media_broken = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 145:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_vue_vue_type_style_index_0_id_118236c8_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(126);
/* harmony import */ var _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_vue_vue_type_style_index_0_id_118236c8_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_vue_vue_type_style_index_0_id_118236c8_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_vue_vue_type_style_index_0_id_118236c8_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_vue_style_loader_index_js_ref_4_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_4_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_4_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_string_replace_loader_index_js_ref_15_Media_vue_vue_type_style_index_0_id_118236c8_lang_postcss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ 146:
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".media[data-v-118236c8]{display:grid;grid-template-columns:[l1] 5% [m1] auto [m2] 5% [r1];grid-template-rows:[t1] 1em auto 1em [b1];grid-gap:0;grid-template-areas:\". . .\" \". media .\" \". . .\";width:100%;overflow:hidden;font-variation-settings:\"wght\" 150,\"wdth\" 80,\"ital\" 0;font-variation-settings:\"wght\" var(--font-weight,150),\"wdth\" var(--font-width,80),\"ital\" 0;margin-left:auto;margin-right:auto;width:100%;max-width:1536px;line-height:1.25}@media (max-width:768px){.media[data-v-118236c8]{grid-template-columns:[l1] 5% [m1] auto [m2] 5% [r1];grid-template-rows:[t1] auto [b1];grid-gap:0;grid-template-areas:\". media .\";min-height:20vh;height:auto;margin-top:2rem}}.media .media_int[data-v-118236c8]{grid-area:media;align-self:center}.media .media_int[data-v-118236c8]{padding-top:0px;padding-bottom:0px}@media (min-width: 768px){.media .media_int[data-v-118236c8]{padding-top:2rem;padding-bottom:2rem}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ 168:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media.vue?vue&type=template&id=118236c8&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"media",attrs:{"id":("media_" + (_vm.media._uid)),"data-scroll-section":""}},[_vm._ssrNode("<div class=\"media_int\" data-v-118236c8>","</div>",[(_vm.media.component == 'video')?_c('Video',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e(),_vm._ssrNode(" "),(_vm.media.component == 'Imagen derecha')?_c('ImagenDerecha',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e(),_vm._ssrNode(" "),(_vm.media.component == 'carrusel')?_c('Carrusel',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e(),_vm._ssrNode(" "),(_vm.media.component == 'Imagenes sobrepuestas')?_c('Sobrepuestas',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e(),_vm._ssrNode(" "),(_vm.media.component == 'Imagen centro full w')?_c('Full',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e(),_vm._ssrNode(" "+((_vm.editor && _vm.media.component == 'broken')?("<div class=\"flex justify-between\" data-v-118236c8><div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>1</div> <div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>2</div> <div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>3</div> <div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>4</div> <div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>5</div> <div class=\"border-l border-grey-200 text-xs px-2\" data-v-118236c8>6</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>7</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>8</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>9</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>10</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>11</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>12</div> <div class=\"border-r border-grey-200 text-xs px-2\" data-v-118236c8>13</div></div>"):"<!---->")+" "),(_vm.media.component == 'broken')?_c('Broken',{attrs:{"media":_vm.media,"data-scroll-trigger":!_vm.$isMobile() ? true : null}}):_vm._e()],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/proyectos/Media.vue?vue&type=template&id=118236c8&scoped=true&

// EXTERNAL MODULE: ./components/proyectos/Media_video.vue + 4 modules
var Media_video = __webpack_require__(133);

// EXTERNAL MODULE: ./components/proyectos/Media_carrusel.vue + 4 modules
var Media_carrusel = __webpack_require__(134);

// EXTERNAL MODULE: ./components/proyectos/Media_sobrepuestas.vue + 4 modules
var Media_sobrepuestas = __webpack_require__(135);

// EXTERNAL MODULE: ./components/proyectos/Media_derecha.vue + 4 modules
var Media_derecha = __webpack_require__(136);

// EXTERNAL MODULE: ./components/proyectos/Media_full.vue + 4 modules
var Media_full = __webpack_require__(137);

// EXTERNAL MODULE: ./components/proyectos/Media_broken.vue + 4 modules
var Media_broken = __webpack_require__(138);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--2-0!./node_modules/@nuxt/components/dist/loader.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/string-replace-loader??ref--15!./components/proyectos/Media.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ var Mediavue_type_script_lang_js_ = ({
  components: {
    Video: Media_video["default"],
    Carrusel: Media_carrusel["default"],
    Sobrepuestas: Media_sobrepuestas["default"],
    Full: Media_full["default"],
    ImagenDerecha: Media_derecha["default"],
    Broken: Media_broken["default"]
  },
  props: {
    media: {
      type: Object,
      default: null
    }
  },

  data() {
    return {
      editor: window.location.search.includes('_storyblok')
    };
  },

  mounted() {
    if (window) {
      window.dispatchEvent(new Event('resize'));
    }
  }

});
// CONCATENATED MODULE: ./components/proyectos/Media.vue?vue&type=script&lang=js&
 /* harmony default export */ var proyectos_Mediavue_type_script_lang_js_ = (Mediavue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(1);

// CONCATENATED MODULE: ./components/proyectos/Media.vue



function injectStyles (context) {
  
  var style0 = __webpack_require__(145)
if (style0.__inject__) style0.__inject__(context)

}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  proyectos_Mediavue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  "118236c8",
  "6dac5fa4"
  
)

/* harmony default export */ var Media = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 89:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7);
/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(gsap__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["a"] = ({
  mounted() {
    if (window) {
      window.dispatchEvent(new Event('resize'));
    }

    this.$Lazyload.$on('loading', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        window.dispatchEvent(new Event('resize'));
      }

      if (el.classList.contains('vlazy')) {
        if (this.$isMobile()) {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(el, {
            clipPath: 'inset(0% 0% 100% 0%)',
            scaleY: 1.1,
            autoAlpha: 0
          });
        } else {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(el, {
            clipPath: 'inset(0% 0% 0% 0%)',
            scaleY: 1,
            autoAlpha: 0
          });
        }
      }
    });
    this.$Lazyload.$on('loaded', ({
      bindType,
      el,
      naturalHeight,
      naturalWidth,
      $parent,
      src,
      loading,
      error
    }, formCache) => {
      if (window) {
        if (el.classList.contains('vlazy')) {
          if (el.classList.contains('vlazy')) {
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(el, {
              clipPath: 'inset(0% 0% 0% 0%)',
              scaleY: 1,
              autoAlpha: 1,
              duration: 0.5,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {
                window.dispatchEvent(new Event('resize'));
              }
            });
          } else {
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(el, {
              clipPath: 'inset(0% 0% 0% 0%)',
              scaleY: 1,
              autoAlpha: 1,
              duration: 0.8,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {
                window.dispatchEvent(new Event('resize'));
              }
            });
          }
        }
      }
    });
  },

  methods: {
    loaded(e) {
      if (window) {
        if (!e.target.classList.contains('isLoaded') && !e.target.classList.contains('isLoading')) {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].set(e.target, {
            // clipPath: 'inset(0% 0% 100% 0%)',
            // webkitClipPath: 'inset(0% 0% 100% 0%)',
            scaleY: 1,
            autoAlpha: 0
          });
        } else {
          gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].to(e.target, {
            // clipPath: 'inset(0% 0% 0% 0%)',
            // webkitClipPath: 'inset(0% 0% 0% 0%)',
            scaleY: 1,
            autoAlpha: 1,
            duration: 0.5,
            ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
            onStart: () => {
              window.dispatchEvent(new Event('resize'));
            }
          });
        }
      }
    },

    clipToRight(e, observer, isIntersecting, ratio) {
      if (isIntersecting) {
        console.log('👓', ' clipToRight', isIntersecting, e, observer);
        e.forEach(function (entry, i) {
          if (entry.target.loaded === false || entry.target.loaded === undefined) {
            entry.target.loaded = true;
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].fromTo(entry.target, {
              clipPath: 'inset(0% 100% 0% 0%)',
              y: 10
            }, {
              clipPath: 'inset(0% 0% 0% 0%)',
              y: 0,
              duration: 1,
              delay: 0.2,
              stagger: i * 0.2,
              overwrite: false,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {},
              onComplete: () => {
                gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].killTweensOf(entry.target);
              }
            });
          }
        });
      }
    },

    clipToTop(e, observer, isIntersecting, ratio) {
      if (isIntersecting) {
        console.log('👓', ' clipToRight', isIntersecting, e, observer);
        e.forEach(function (entry, i) {
          if (entry.target.loaded === false || entry.target.loaded === undefined) {
            entry.target.loaded = true;
            gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].fromTo(entry.target, {
              clipPath: 'inset(100% 0% 0% 0%)',
              y: 10
            }, {
              clipPath: 'inset(0% 0% 0% 0%)',
              y: 0,
              duration: 1,
              delay: 0.2,
              stagger: i * 0.2,
              overwrite: false,
              ease: gsap__WEBPACK_IMPORTED_MODULE_0__["Power2"].easeInOut,
              onStart: () => {},
              onComplete: () => {
                gsap__WEBPACK_IMPORTED_MODULE_0__["gsap"].killTweensOf(entry.target);
              }
            });
          }
        });
      }
    }

  }
});

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(115);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("594f6c7c", content, true, context)
};

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(117);
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add CSS to SSR context
var add = __webpack_require__(5).default
module.exports.__inject__ = function (context) {
  add("29beb825", content, true, context)
};

/***/ })

};;
//# sourceMappingURL=proyectos-media.js.map